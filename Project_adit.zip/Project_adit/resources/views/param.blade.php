<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZZZ</title>
</head>
<body>

    <h1><center>Halaman Param</center></h1>
    <p>Nama : {{$nama3}} </p>
    <p>Jenis Kelamin : {{$jk3}} </p>
    <p>Alamat : {{$almt3}} </p>
    <p>Pendidikan : {{$pnddkn3}} </p>
    <p>Pekerjaan : {{$pkrjn3}} </p>
</body>
</html>