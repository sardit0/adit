<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZZZ</title>
</head>
<body>

    <h1><center>Selamat Datang Di Halaman Home</center></h1>

</body>
</html><?php /**PATH C:\xampp\htdocs\Project_adit\resources\views/biodata2.blade.php ENDPATH**/ ?>