<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZZZ</title>
</head>
<body>

    <h1><center>Selamat Datang Di Halaman Biodata</center></h1>
    <p>Nama : <?php echo e($nama); ?> </p>
    <p>Jenis Kelamin : <?php echo e($jk); ?> </p>
    <p>Alamat : <?php echo e($almt); ?> </p>
    <p>Pendidikan : <?php echo e($pnddkn); ?> </p>
    <p>Pekerjaan : <?php echo e($pkrjn); ?> </p>
</body>
</html><?php /**PATH C:\xampp\htdocs\Project_adit\resources\views/biodata.blade.php ENDPATH**/ ?>