<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZZZ</title>
</head>
<body>

    <h1><center>Halaman Param</center></h1>
    <p>Nama : <?php echo e($nama3); ?> </p>
    <p>Jenis Kelamin : <?php echo e($jk3); ?> </p>
    <p>Alamat : <?php echo e($almt3); ?> </p>
    <p>Pendidikan : <?php echo e($pnddkn3); ?> </p>
    <p>Pekerjaan : <?php echo e($pkrjn3); ?> </p>
</body>
</html><?php /**PATH C:\xampp\htdocs\Project_adit\resources\views/param.blade.php ENDPATH**/ ?>